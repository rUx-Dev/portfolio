<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<title> Guest </title>
	<link rel="stylesheet" type="text/css" href="s.css">
	<link href="https://fonts.googleapis.com/css?family=Mr+De+Haviland" rel="stylesheet">
<body>

	<div class="container">
		<h1> Scrabble Scorekeeper </h1>
		<h1> Guest   Home Page </h1>
		<a href="viewsched.php" class="btn"> View Schedule </a>
		<a href="viewresults.php" class="btn"> View Results </a>
		
	</div>
