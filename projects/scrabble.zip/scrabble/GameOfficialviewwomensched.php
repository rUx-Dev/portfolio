<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "scorekeeper";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM womensched";
$result = $conn->query($sql);
?>

<head>
  <title>Women Game Schedule</title>
     <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <link rel="stylesheet" type="text/css" href="optioncss.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <body>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </head>

  <body>
  <style>
    a .back {
  position: absolute;
    right: 20px;
    margin: 3px;
    height: 50px;
    width: 120px;
    background: linear-gradient(to right, rgba(184,21,0,1) 0%, rgba(137,4,8,0.95) 45%, rgba(231,56,39,0.89) 100%);
  border-radius: 4px;
  padding: 15px 38px;
  object-position: center;
  color: #FFFFFF;
  font: 15px 'Neuton', serif;
  text-transform:uppercase;
  text-decoration: none;
  text-align: center;
  text-shadow: 0px 2px 4px rgba(0,0,0,3);
  -webkit-transition: box-shadow 1s ease;
    transition: box-shadow 1s ease;
    }
  </style>
  <nav class="navbar navbar-inverse navbar-fixed-top">
   <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#"><img src="images/aclc.png"></a>
  <a class="back" href="gameofficialhome.php" style="color: red;"> <button class="back"> Back </button> </a>
    </div>
    <center>
      <P> <FONT COLOR="white" size="6px"> ACLC SCRABBLE SCOREKEEPER </P> </FONT>
      </center>

 
    </ul>
  </div>
</nav>
      <br><br>
      <div class="container">
        <div class="header">
        <center> <br>
  <h2>Women Division Game Schedule</h2> 
  </center> 
  </div>         
  <table class="table table-hover">
    <thead>
<br>
      <tr>
        <th>Game ID</th>
        <th>House A</th>
        <th>House B</th>
        <th>Date</th>
        <th>Time</th>
        <th>Venue</th>
      </tr>
<?php
      while($schedules = $result->fetch_assoc()) {
        
        echo "<tr>";
        echo "<td>".$schedules['gameid']."</td>";

        echo "<td>".$schedules['house_A']."</td>";

      echo "<td>".$schedules['house_B']."</td>";

        echo "<td>".$schedules['date']."</td>";

        echo "<td>".$schedules['time']."</td>";

      echo "<td>".$schedules['venue']."</td>";
     } //endwhile
?>

</tbody>
  </table>
</div>
      
  </table>
</body>
</html>
