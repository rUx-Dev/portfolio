<?php
include('functions.php');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
  <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
     <link   href="style.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Mr+De+Haviland" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#"><img src="images/aclc.png"></a>
     
    </div>
    <center>
      <P> <FONT COLOR="white" size="6px"> ACLC SCRABBLE SCOREKEEPER <P> </FONT>
      </center>
    </ul>
  </div>
</nav>

    <div class="header">
        <center>
          <br><bR>
        <h2>Login</h2>
    </center>
    </div>
    <style>
         h3 {
  color: #E0E0E0;
  text-shadow:  0px 2px 4px rgba(0,0,0,6);
  margin-bottom: 24px;
}

    </style>
    <form class= "loginform" method="post" action="login.php">

        <?php
echo display_error();
?>
        <center>
        <div class="input-group">
            <label>Username</label>
            <input type="text" name="username" required value="<?php
			echo $username;
			?>">
        </div>
        <div class="input-group">
            <label>Password</label>
            <input type="password" name="password" required value="<?php
echo $password;
?>">
        </div>
        <div class="input-group">
            <button type="submit" class="button" name="login_btn">Login</button>
        </div>
      </center>
    </form>
</body>
</html>