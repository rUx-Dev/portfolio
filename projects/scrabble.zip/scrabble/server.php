<?php
	session_start();

// variable declaration
$name = "";
$contactnumber    = "";
$gender = "";
$course = "";
$year = "";
$house = "";
$errors = array(); 
$_SESSION['success'] = "";
	// connect to  the db
	$db = mysqli_connect('localhost','root','','scorekeeper');

	// if submit button is clicked
	if(isset($_POST['addplayer'])) {
	$name = mysqli_real_escape_string($db, $_POST['name']);
	$gender = mysqli_real_escape_string($db, $_POST['gender']);
	$contactnumber = mysqli_real_escape_string($db, $_POST['contactnumber']);
	$course = mysqli_real_escape_string($db, $_POST['course']);
	$year = mysqli_real_escape_string($db, $_POST['year']);
	$house = mysqli_real_escape_string($db, $_POST['house']);


	// ensure that the fields are filled properly
		if(empty($name)) {
			array_push($errors, "Player Name is required");
		}
		if(empty($gender)) {
			array_push($errors, "Gender is required");
		}
		if(empty($contactnumber)) {
			array_push($errors, "Contact Number is required");
		}
		if(empty($course)) {
			array_push($errors, "Course is required");
		}
		if(empty($year)) {
			array_push($errors, "Year Level Name is required");
		}
		if(empty($house)) {
			array_push($errors, "House Name is required");
		}
		// if no errors, save player to database
		if (count($errors) == 0) {
			$sql = "INSERT INTO players (fullname, gender, contactnumber, course, year, house) VALUES ('$name', '$gender' ,'$contactnumber', '$course', '$year', '$house')";
			mysqli_query($db, $sql);

			$_SESSION['success']  = "Player successfully saved!";
			header('location: adminhomepage.php');		
		}
	}
	?>
