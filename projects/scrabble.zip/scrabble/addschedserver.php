<?php
	session_start();

// variable declaration
$house_A = "";
$house_B    = "";
$date = "";
$time = "";
$venue = "";
$errors = array(); 
$_SESSION['success'] = "";
	// connect to  the db
	$db = mysqli_connect('localhost','root','','scorekeeper');

	// if submit button is clicked
	if(isset($_POST['addsched'])) {
	$house_A = mysqli_real_escape_string($db, $_POST['house_A']);
	$house_B = mysqli_real_escape_string($db, $_POST['house_B']);
	$date = mysqli_real_escape_string($db, $_POST['date']);
	$time = mysqli_real_escape_string($db, $_POST['time']);
	$venue = mysqli_real_escape_string($db, $_POST['venue']);


	// ensure that the fields are filled properly
		if(empty($house_A)) {
			array_push($errors, "House A is required");
		}
		if(empty($date)) {
			array_push($errors, "Date of the game is required");
		}
		if(empty($time)) {
			array_push($errors, "Time of the game is required");
		}
		if(empty($venue)) {
			array_push($errors, "Venue of the game is required");
		}
		// if no errors, save player to database
		if (count($errors) == 0) {
			$sql = "INSERT INTO womensched (house_A, house_B, `date`, `time`, venue) VALUES ('$house_A', '$house_B', '$date', '$time', '$venue')";
			mysqli_query($db, $sql);

			$_SESSION['house_A'] = $house_A;

			$_SESSION['success']  = "Schedule successfully saved!";
			header('location: adminhomepage.php');		
			}
		}



	?>