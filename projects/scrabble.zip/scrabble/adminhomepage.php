	<?php
include ('functions.php');
?>

	<!DOCTYPE html>
	<html>
	<head>
	<title>ACLC Scrabble Scorekeeper</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	  <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1">
  	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 	 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>

	<body>
	<style>
	a .logout {
	position: absolute;
    right: 20px;
    top: 0px;
    margin: 3px;
    height: 50px;
    width: 150px;
    background: linear-gradient(to right, rgba(184,21,0,1) 0%, rgba(137,4,8,0.95) 45%, rgba(231,56,39,0.89) 100%);
	border-radius: 4px;
	padding: 15px 38px;
	object-position: center;
	color: #FFFFFF;
	font: 15px 'Neuton', serif;
	text-transform:uppercase;
	text-decoration: none;
	text-shadow: 0px 2px 4px rgba(0,0,0,3);
	-webkit-transition: box-shadow 1s ease;
		transition: box-shadow 1s ease;
		}
	</style>

	<nav class="navbar navbar-inverse navbar-fixed-top">
 	 <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#"><img src="images/aclc.png"></a>
      <a class= "logout" href="index.php?logout='1'" style="color: red;"> <button class="logout" > Logout </button> </a>
    </div>
    <center>
      <P> <FONT COLOR="white" size="6px"> ACLC SCRABBLE SCOREKEEPER </P> </FONT>
      </center>
	</div>
	</nav>

	 <div class="header">
	 <br> <br>
     <h3> Home </h3>
    </div>
	<div class="content">
	<!-- notification message -->
	<?php if (isset($_SESSION['success'])): ?>
	<div class="error success" >
	<h3>
	<?php
    echo $_SESSION['success'];
    unset($_SESSION['success']);
?>
	</h3>
	</div>
	<?php
endif ?>
	<!-- logged in user information -->
	<div class="profile_info">
	<img src="images/user_profile.png" width=100 height=100" >
	
	<div>
	<?php if (isset($_SESSION['user'])): ?>
	<strong> <p> WELCOME </p><?php echo $_SESSION['user']['fullname']; ?></strong>

	<small>
	<i  style="color: #888;">(<?php echo ucfirst($_SESSION['user']['usertype']); ?>)</i>

	<br>

	</small>

	<?php
endif ?>
	</div>
	</div>
	<center>

	<div class="input-group">
		<a href="addplayer.php"> <button type="addplayer" class="btn" name="addplayer_btn"> Add Player  </button> </a> 
	</div>

	<div class="input-group">
	<a href="div.php" ><button type="addpsched" class="btn" name="addpschedule_btn"> Create Schedule </button> </a>
	</div>

	<div class="input-group">
	<a href="adduser.php" ><button type="adduser" class="btn" name="adduser_btn"> Create User </button> </a>
	</div>


	<div class="input-group">
	<a href="viewplayers.php" ><button type="viewplayer" class="btn" name="viewplayer_btn"> View Players </button> </a>
	</div>

	<div class="input-group">
	<a href="viewresults.php" ><button type="viewresults" class="btn" name="viewresults_btn"> View Results </button> </a>
	</div>
	<div class="input-group">
	<a href="viewuser.php" ><button type="viewuser" class="btn" name="viewuser_btn"> View User</button> </a>
	</div> 


	<div class="input-group">
	<a href="viewschedmen.php" ><button type="viewsched" class="btn" name="viewsched_btn"> Men Division Schedule </button> </a>
	</div>

	<div class="input-group">
	<a href="viewschedwomen.php" ><button type="viewsched" class="btn" name="viewsched_btn"> Women Division Schedule </button> </a>
	</div>
	</div>
	</center>

	</body>
	</html>