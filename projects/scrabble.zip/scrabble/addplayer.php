<?php include('server.php'); ?>

<!DOCTYPE html>
<html>
<head>
	<title> Add Player </title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="optioncss.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<body>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>

	<body>
	<style>
		a .back {
	position: absolute;
    right: 20px;
    margin: 3px;
    height: 50px;
    width: 120px;
    background: linear-gradient(to right, rgba(184,21,0,1) 0%, rgba(137,4,8,0.95) 45%, rgba(231,56,39,0.89) 100%);
	border-radius: 4px;
	padding: 15px 38px;
	object-position: center;
	color: #FFFFFF;
	font: 15px 'Neuton', serif;
	text-transform:uppercase;
	text-decoration: none;
	text-align: center;
	text-shadow: 0px 2px 4px rgba(0,0,0,3);
	-webkit-transition: box-shadow 1s ease;
		transition: box-shadow 1s ease;
		}
	</style>
	<nav class="navbar navbar-inverse navbar-fixed-top">
 	 <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#"><img src="images/aclc.png"></a>
 	<a class="back" href="adminhomepage.php" style="color: red;"> <button class="back"> Back </button> </a>
    </div>
    <center>
      <P> <FONT COLOR="white" size="6px"> ACLC SCRABBLE SCOREKEEPER </P> </FONT>
      </center>

 
    </ul>
  </div>
</nav>

	<div class="header">
		<br><br>
		<h3> Add Player Form</h3>
	</div>

	<form method="post" action="addplayer.php">
		<?php include('errors.php'); ?>
<center>
				<div class="input-group">
			<label> Player Fullname: </label>
			<input type="text" name="name" required value="<?php echo $name; ?>">
		</div>

		<div class="input-group">
			<label> Gender: </label>
			<select id="soflow-color" name="gender" required value="<?php echo $gender; ?>">
 			<option value="" disabled selected> Gender </option>
 			<option> Male </option>
        	<option> Female </option>
</select>
</div>
		<div class="input-group">
			<label> Contact Number: </label>
			<input type="number" placeholder="+63" name="contactnumber" required value="<?php echo $contactnumber; ?>">
</div>

		<div class="input-group">			
			<label> Course: </label>
			<select id="soflow-color" name="course" required value="<?php echo $course; ?>">
 			<option value="" disabled selected>Course</option>
 			<option> B.S. in Computer Science </option>
        	<option> B.S. in Information Technology </option>
        	<option> B.S in Accountancy</option>
        	<option> B.S. in Business Administration</option>
        	<option> B.S. in Hotel and Restaurant Management</option>
            <option> Computer Systems and Network Technology </option>
       	    <option> Computer-Based Accountancy</option>
       	     <option> Office and Information Systems</option>
       	    <option> Software Development</option>
       	    <option> Web Applications Development
			</option>
			</select>
		</div>
		<div class="input-group">
			<label> Year Level: </label>
			<select id="soflow-color" name="year" required value="<?php echo $year; ?>">
 			<option value="" disabled selected> Year Level </option>
 			<option> 1st year </option>
        	<option> 2nd year</option>
        	<option> 3rd year</option>
        	<option> 4th year</option>
        	<option> 5th year</option>
        </select>
		</div>
		<div class="input-group">
			<label> House Name: </label>
			<select id="soflow-color" required name="house" required value="<?php echo $house; ?>">
 			<option value="" disabled selected> House Name </option>
 			<option> Azul </option>
        	<option> Cahel </option>
        	<option> Giallio</option>
        	<option> Roxxo</option>
        	<option> Vierrdy</option>
            <option> Black Mamba </option>
       	    <option> White Scorpions</option>
			</select>
		</div>
		<br>
		<div class="input-group">
			<button type="submit" name="addplayer"> Submit</button>
		</div>

	</form>
</body>
</html>

