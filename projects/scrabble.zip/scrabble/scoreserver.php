<?php
	session_start();

// variable declaration
$score ="";
$playername="";
$errors = array(); 
$_SESSION['success'] = "";
	// connect to  the db
	$db = mysqli_connect('localhost','root','','scorekeeper');

	// if submit button is clicked
	if(isset($_POST['finishgame'])) {
	$score = mysqli_real_escape_string($db, $_POST['score']);
	$playername= mysqli_real_escape_string($db, $_POST['playername']);

			$sql = "INSERT INTO results (gameid, playername, score, result) VALUES ('1', '$playername', '$score', 'giallio')";
			mysqli_query($db, $sql);

			$_SESSION['success']  = "Game successfully finished!";
			header('location: adminhomepage.php');		
		}
	}
	?>
