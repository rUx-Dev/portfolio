<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "scorekeeper";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM schedules";
$result = $conn->query($sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <link   href="style.css" rel="stylesheet">
    <link   href="s.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Mr+De+Haviland" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
</head>
 
  <body>

    <div class="container">
    <div class="row">
    <h4> Scrabble Game Schedule</h4>
    </div>
    <div class="row">
    <style>
    h4 {
  color: #0F136E;
  font: 900 80px 'Mr De Haviland', cursive;
  text-shadow:  0px 2px 4px rgba(0,0,0,6);
  margin-bottom: 24px;

}
  table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
  }

  td, th {
    border: 1px solid #dddddd;
    text-align: left;
    padding: 8px;
  }
  </style>
                 
       <table id="table">
      <thead>
      <tr>
        <th>Game ID</th>
        <th>Team A</th>
        <th>Team B</th>
        <th>Date</th>
        <th>Time</th>
        <th>Venue</th>
      </tr>
      </thead>
      </tbody>

        <form action="Scorekeeper-master/" method="get">
          <div class="input-group">
        Game ID:<input type="text" name="gameid" id="gameid"><br><br>
        Team A:<input type="text" name="teamA" id="teamA"><br><br>
        Team B:<input type="text" name="teamB" id="teamB"><br><br>
        <input type = "submit" name="play" class="btn" value="Play Now">
      </div>
        </form>

     <?php
     $sql = "SELECT * FROM schedules";
        foreach ($conn->query($sql) as $row) {
        echo '<tr>';
        echo "<td class='clickable'>".$row['gameid']."</td>";
        echo "<td>".$row['teamA']."</td>";
        echo "<td>".$row['teamB']."</td>";
        echo "<td>".$row['date']."</td>";
        echo "<td>".$row['time']."</td>";
        echo "<td>".$row['venue']."</td>";
                         
        }
        ?>

         <script>
    
                var table = document.getElementById('table');
                
                for(var i = 1; i < table.rows.length; i++)
                {
                    table.rows[i].onclick = function()


                    {
                         //rIndex = this.rowIndex;
                         document.getElementById("gameid").value = this.cells[0].innerHTML ;
                         document.getElementById("teamA").value = this.cells[1].innerHTML;
                         document.getElementById("teamB").value = this.cells[2].innerHTML;
                    };
                }
    
         </script>
   </tbody>
   </table> 
   </div>
    </div> <!-- /container -->
  </body>
</html>