-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 31, 2018 at 10:43 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scorekeeper`
--

-- --------------------------------------------------------

--
-- Table structure for table `mensched`
--

CREATE TABLE `mensched` (
  `gameid` int(11) NOT NULL,
  `house_A` varchar(255) NOT NULL,
  `house_B` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `venue` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mensched`
--

INSERT INTO `mensched` (`gameid`, `house_A`, `house_B`, `date`, `time`, `venue`) VALUES
(5, 'Vierrdy - Nino Noval Apas', 'Cahel - Junard Santos', '2018-07-02', '14:30', '103');

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `playerid` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `gender` varchar(225) NOT NULL DEFAULT 'male, female',
  `contactnumber` varchar(20) NOT NULL,
  `course` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `house` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`playerid`, `fullname`, `gender`, `contactnumber`, `course`, `year`, `house`) VALUES
(1, 'Angelica Seldura', 'Female', '+639424727959', 'B.S. in Information Technology', '3rd year', 'Giallio'),
(4, 'Jocelyn Villaquer', 'Female', '+639234389794', 'B.S. in Information Technology', '3rd year', 'Vierrdy'),
(11, 'Nino Noval Apas', 'Male', '+63921345675', 'B.S. in Information Technology', '3rd year', 'Vierrdy'),
(12, 'Junard Santos', 'Male', '+639216475856', 'B.S. in Accountancy', '4th year', 'Cahel');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `gameid` int(11) NOT NULL,
  `house_A` varchar(255) NOT NULL,
  `house_A_totalscore` varchar(255) NOT NULL,
  `house_B` varchar(255) NOT NULL,
  `house_B_totalscore` varchar(255) NOT NULL,
  `winner` varchar(255) NOT NULL,
  `loser` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `usertype` varchar(255) NOT NULL DEFAULT 'admin, game official'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `fullname`, `username`, `password`, `usertype`) VALUES
(13, 'Angelica Seldura', 'selduraangelica', '5f4dcc3b5aa765d61d8327deb882cf99', 'scorekeeper'),
(14, 'Jocelyn Villaquer', 'villaquerjocelyn', '5f4dcc3b5aa765d61d8327deb882cf99', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `womensched`
--

CREATE TABLE `womensched` (
  `gameid` int(11) NOT NULL,
  `house_A` varchar(255) NOT NULL DEFAULT 'Azul, Cahel, Giallio, Roxxo, Vierddy, Black Mamba, White Scorpions',
  `house_B` varchar(255) NOT NULL DEFAULT 'Azul, Cahel, Giallio, Roxxo, Vierddy, Black Mamba, White Scorpions',
  `date` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `venue` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `womensched`
--

INSERT INTO `womensched` (`gameid`, `house_A`, `house_B`, `date`, `time`, `venue`) VALUES
(1, 'Azul', 'White Scorpions', 'August 3, 2018', '1:00', '103');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mensched`
--
ALTER TABLE `mensched`
  ADD PRIMARY KEY (`gameid`);

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`playerid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- Indexes for table `womensched`
--
ALTER TABLE `womensched`
  ADD PRIMARY KEY (`gameid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mensched`
--
ALTER TABLE `mensched`
  MODIFY `gameid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `playerid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `womensched`
--
ALTER TABLE `womensched`
  MODIFY `gameid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
