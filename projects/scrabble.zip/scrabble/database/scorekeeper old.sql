-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2017 at 03:13 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scorekeeper`
--

-- --------------------------------------------------------

--
-- Table structure for table `players`
--

CREATE TABLE `players` (
  `playerid` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `contactnumber` varchar(20) NOT NULL,
  `course` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `house` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`playerid`, `fullname`, `contactnumber`, `course`, `year`, `house`) VALUES
(1, 'Angelica Seldura', '2147483647', 'BSIT', '3rd yr', 'Giallio'),
(4, 'Jacob Seldura', '932536272', 'BSBA', '1st year', 'Giallio'),
(5, 'Jocelyn Villaquer', '2147483647', 'B.S. in Information Technology', '3rd year', 'Vierrdy'),
(6, 'Julia Santos', '2147483647', 'Computer Systems and Network Technology', '2nd year', 'Cahel'),
(7, 'Lunacy Dablo', '2147483647', 'B.S. in Computer Science', '1st year', 'Cahel'),
(8, 'Hesel Agot', '09234567890', 'B.S in Accountancy', '2nd year', 'Giallio'),
(9, 'Faith Seldura', '0923334345', 'B.S in Accountancy', '1st year', 'Giallio'),
(10, 'Samuel Seldura', '09772641', 'B.S in Accountancy', '1st year', 'Cahel'),
(11, 'skb', '089787', 'B.S. in Information Technology', '2nd year', 'Cahel');

-- --------------------------------------------------------

--
-- Table structure for table `results`
--

CREATE TABLE `results` (
  `gameid` int(11) NOT NULL,
  `playername` varchar(255) NOT NULL,
  `score` varchar(255) NOT NULL,
  `result` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `gameid` int(11) NOT NULL,
  `teamA` varchar(255) NOT NULL DEFAULT 'Azul, Cahel, Giallio, Roxxo, Vierddy, Black Mamba, White Scorpions',
  `teamB` varchar(255) NOT NULL DEFAULT 'Azul, Cahel, Giallio, Roxxo, Vierddy, Black Mamba, White Scorpions',
  `date` varchar(255) NOT NULL,
  `time` varchar(255) NOT NULL,
  `venue` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`gameid`, `teamA`, `teamB`, `date`, `time`, `venue`) VALUES
(1, 'Giallio', 'Roxxo', 'September 7, 2017', '3:00 pm', 'room 201'),
(2, 'Vierrdy', 'Giallio', 'September 7, 2017', '3:00 pm', 'room 201'),
(3, 'Cahel', 'Black Mamba', 'September 8, 2017', '1:00 pm', 'room 203'),
(4, 'Giallio', 'Cahel', 'September 10, 2017', '4:00 pm', 'room 203'),
(5, 'Azul', 'Cahel', 'September 8, 2017', '3:00 pm', 'room 201');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(11) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `usertype` varchar(255) NOT NULL DEFAULT 'admin, game official'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `fullname`, `username`, `password`, `usertype`) VALUES
(1, 'Daniel Padilla', 'agentyellow', '5f4dcc3b5aa765d61d8327deb882cf99', 'admin'),
(2, 'Kathryn Bernardo', 'bernardokath', '5f4dcc3b5aa765d61d8327deb882cf99', 'game official'),
(9, 'Phoelyn Lopez', 'phoelynlopez', '5f4dcc3b5aa765d61d8327deb882cf99', 'Game Official'),
(10, 'Jocelyn Villaquer', 'jocelynvillaquer', '5f4dcc3b5aa765d61d8327deb882cf99', 'game official'),
(11, 'Angelica Seldura', 'angelicaseldura', '5f4dcc3b5aa765d61d8327deb882cf99', 'admin'),
(12, 'admin', 'admin', '5f4dcc3b5aa765d61d8327deb882cf99', 'admin'),
(13, 'gameofficial', 'gameofficial', '5f4dcc3b5aa765d61d8327deb882cf99', 'game official'),
(14, 'admin', 'admin', '5f4dcc3b5aa765d61d8327deb882cf99', 'Admin'),
(15, 'admin', 'as', 'f970e2767d0cfe75876ea857f92e319b', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `players`
--
ALTER TABLE `players`
  ADD PRIMARY KEY (`playerid`);

--
-- Indexes for table `schedules`
--
ALTER TABLE `schedules`
  ADD PRIMARY KEY (`gameid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `players`
--
ALTER TABLE `players`
  MODIFY `playerid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `schedules`
--
ALTER TABLE `schedules`
  MODIFY `gameid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
